package com.kunall17.entryscreenmanager.Java;

/**
 * Created by kunall17 on 1/4/16.
 */
public interface ContactInterface {

    void setContainerBackground(int COLOR);

    void setControlsBackground(int Color);

    void setControlsTextColor(int color);

    void setControlShown(Boolean state);
}
